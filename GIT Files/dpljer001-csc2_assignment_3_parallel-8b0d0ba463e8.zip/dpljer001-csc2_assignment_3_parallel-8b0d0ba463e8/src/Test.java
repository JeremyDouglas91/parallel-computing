import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Test {

    public static void main(String[] args) throws IOException{
        BufferedReader br1 = new BufferedReader(new FileReader("data/toFile.txt"));
        BufferedReader br2 = new BufferedReader(new FileReader("data/sample_output.txt"));

        double s1 = Double.parseDouble(br1.readLine());
        double s2 = Double.parseDouble(br2.readLine());
        int count = 0;
        while(count<1000001){
            if(s1-s2 != 0.0)
                System.out.println(count);
            s1 = Double.parseDouble(br1.readLine());
            s2 = Double.parseDouble(br2.readLine());
            count++;
        }

    }
}
